'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
'''

'''
Samantha Bennefield
1/9/18
Mr. Davis
Quest
Alpha Version 1
'''

import sys
import pygame
import random
import time
import subprocess

pygame.init()

WIDTH = 700
HEIGHT = 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Quest (Alpha 1)")

#COLORS
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (150, 150, 150)

#CLOCK
clock = pygame.time.Clock()

#FONT
fontObj = pygame.font.Font('freesansbold.ttf', 32)

#TEXT
textObj = fontObj.render('GAME OVER', True, WHITE)
textRect = textObj.get_rect()
textRect.center = (350, 300)

#MUSIC
pygame.mixer.init()
pygame.mixer.music.load("We're all under the stars.mp3")
pygame.mixer.music.set_volume(0.7)
pygame.mixer.music.play(-1, 0.0) #<--- Plays infinitely

effect = pygame.mixer.Sound("NFF-zing.wav")

class Option:
    def __init__(self, text, pos, color):
        self.text = text
        self.pos = pos
        self.color = color
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

    def set_rend(self):
        self.rend = fontObj.render(self.text, True, self.color)

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos

restarttext = Option("Restart", (290, 400), WHITE)
quittext = Option("Quit", (310, 450), WHITE)

click = 0


def open_program(path_name):
    return subprocess.Popen(path_name)

def close_program(p):
    p.terminate()

#GAME LOOP
while True:
    clock.tick(60)
    mouse_pos = pygame.mouse.get_pos()

    if pygame.mouse.get_pressed()[0] and restarttext.rect.collidepoint(mouse_pos):
        if click == 0:
            effect.play()
            pygame.time.delay(500)
            p = open_program(['python.exe', 'quest_main_alpha.py'])
            pygame.quit()
            sys.exit()
            click += 1
    elif pygame.mouse.get_pressed()[0] and quittext.rect.collidepoint(mouse_pos):
        if click == 0:
            effect.play()
            pygame.time.delay(500)
            pygame.quit()
            sys.exit()

    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if restarttext.rect.collidepoint(mouse_pos):
            restarttext.color = GRAY
            restarttext.draw()
        else:
            restarttext.color = WHITE
            restarttext.draw()

        if quittext.rect.collidepoint(mouse_pos):
            quittext.color = GRAY
            quittext.draw()
        else:
            quittext.color = WHITE
            quittext.draw()

    screen.fill(BLACK)
    screen.blit(textObj, textRect)

    restarttext.draw()
    quittext.draw()
    pygame.display.flip()
