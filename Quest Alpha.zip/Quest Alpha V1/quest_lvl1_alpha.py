'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
'''

'''
Samantha Bennefield
1/9/18
Mr. Davis
Quest
Alpha Version 1
'''

import sys
import pygame
import random
import time
import subprocess

pygame.init()

WIDTH = 700
HEIGHT = 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Quest (Alpha 1)")

#COLORS
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (200,  200, 200)
RED   = (255, 0 , 0)
GREEN = (0, 255, 0)
BLUE  = (0, 0, 255)

#BACKGROUND IMG
#**Image size: 2000 x 2000
bg = pygame.image.load('map.png')
fightbg = pygame.image.load('fight_placehold.png')

#PLAYER OVERWORLD SPRITES
#**Sprite size: 128 x 128
player_start = pygame.image.load('forward_1.png')
player_down  = ['forward_1.png', 'forward_2.png', 'forward_3.png']
player_up = ['back_1.png', 'back_2.png', 'back_3.png']
player_left = ['left_1.png', 'left_2.png']
player_right = ['right_1.png', 'right_2.png']

#PLAYER FIGHT SPRITES
player_idle = pygame.image.load('fight_3.png')
player_attack = ['fight_2.png']
player_defend = ['fight_4.png']
player_hit = ['fight_3.png']
player_potion = ['fight_3.png']
player_defeat = ['fight_3.png']

#PLAYER WALK ANIMATION
global pressed_left
global pressed_right
global pressed_up
global pressed_down

pressed_left = False
pressed_right = False
pressed_up = False
pressed_down = False

up_counter = 0
down_counter = 0
right_counter = 0
left_counter = 0

#ENEMY FIGHT SPRITES
enemy1_idle = pygame.image.load('enemy1_4.png')
enemy1_attack = ['enemy1_2.png']
enemy1_defnd = ['enemy1_1.png']
enemy1_hit = ['enemy1_3.png']
enemy1_buff = ['enemy1_2.png']
enemy1_defeat = ['enemy1_3.png']

enemy2_idle = pygame.image.load('enemy2_1.png')
enemy2_attack = ['enemy2_2.png']
enemy2_defnd = ['enemy2_1.png']
enemy2_hit = ['enemy2_3.png']
enemy2_buff = ['enemy2_2.png']
enemy2_defeat = ['enemy2_3.png']

enemy3_idle = pygame.image.load('enemy3_4.png')
enemy3_attack = ['enemy3_2.png']
enemy3_defnd = ['enemy3_1.png']
enemy3_hit = ['enemy3_3.png']
enemy3_buff = ['enemy3_2.png']
enemy3_defeat = ['enemy3_3.png']

enemy4_idle = pygame.image.load('enemy4_4.png')
enemy4_attack = ['enemy4_2.png']
enemy4_defnd = ['enemy4_1.png']
enemy4_hit = ['enemy4_3.png']
enemy4_buff = ['enemy4_2.png']
enemy4_defeat = ['enemy4_3.png']

enemy5_idle = pygame.image.load('enemy5_4.png')
enemy5_attack = ['enemy5_2.png']
enemy5_defnd = ['enemy5_1.png']
enemy5_hit = ['enemy5_3.png']
enemy5_buff = ['enemy5_2.png']
enemy5_defeat = ['enemy5_3.png']

#CLOCK
clock = pygame.time.Clock()

#FONT
fontObj = pygame.font.Font('freesansbold.ttf', 32)

#WHO'S TURN
#Player = 0, Enemy = 1, additional enemies = 2+
global turn
turn = 0

#WORLD MAP
world = pygame.Surface((3000, 3000))

#MOUSE BUTTON
global mouse_down
mouse_down = False

#MUSIC AND SOUND EFFECTS
pygame.mixer.init()
pygame.mixer.music.load("Jumpshot.mp3")
pygame.mixer.music.set_volume(0.7)
pygame.mixer.music.play(-1, 0.0) #<--- Plays infinitely

walk_sound = pygame.mixer.Sound("Walking-through- leaves-sound-effect.wav")
swing_sound = pygame.mixer.Sound("NFF-knife-hit.wav")
hit_sound = pygame.mixer.Sound("NFF-magic-exploding.wav")
select_sound = pygame.mixer.Sound("NFF-move-select.wav")
select_sound2 = pygame.mixer.Sound("NFF-zing.wav")
buff_sound = pygame.mixer.Sound("NFF-spell.wav")
defnd_sound = pygame.mixer.Sound("NFF-quick-move.wav")
potion_sound = pygame.mixer.Sound("NFF-spell.wav")




#Open and close other python programs
def open_program(path_name):
    return subprocess.Popen(path_name)

def close_program(p):
    p.terminate()


#Player Class for Overworld
class Player():
    global location
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.image = player_start
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height) #<-- Sizing is probably off      
        
    def move(self,camera_pos):
        global location
        pos_x,pos_y = camera_pos #<-- Split camera_pos

        #Moving camera and character
        #**Camera refers to the part of the screen the player can see
        key = pygame.key.get_pressed()
        if key[pygame.K_UP]:
            self.y += 8
            pos_y += 8 #<-- Move Camera with Player
        if key[pygame.K_LEFT]:
            self.x += 8
            pos_x += 8
        if key[pygame.K_DOWN]:
            self.y -= 8
            pos_y -= 8
        if key[pygame.K_RIGHT]:
            self.x -= 8
            pos_x -= 8

        #Collision
        if self.x < -1400:
            self.x = -1400
            pos_x = camera_pos[0]
        elif self.x > 500:
            self.x = 500
            pos_x = camera_pos[0]
        if self.y < -1400:
            self.y = -1400
            pos_y = camera_pos[1]
        elif self.y > 500:
            self.y = 500
            pos_y = camera_pos[1]
            
        return (pos_x,pos_y)
    
    def render(self, screen):
        screen.blit(self.image,(self.rect.x,self.rect.y))

#Player Class for Fight Screen
class Player_Fight():
    global fight_text
    global start_screen
    def __init__(self, x, y, width, height, hp, atk, defnd, potion_num, defnd_success):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.image = player_idle
        
        self.hp = hp
        self.atk = atk
        self.defnd = defnd
        self.potion_num = potion_num #<-- Number of potions
        self.defnd_success = defnd_success #<-- If defend action is successful

        #For sprite animations
        self.atk_counter = 0
        self.def_counter = 0
        self.hit_counter = 0
        self.potion_counter = 0

    def dead(self): #<-- If hp <= 0
        pygame.time.delay(1000)
        p = open_program(['python.exe', 'game_over_alpha.py'])
        pygame.quit()
        sys.exit()

    def atk_animation(self):
        self.image = pygame.image.load(player_attack[self.atk_counter])
        self.atk_counter = (self.atk_counter + 1) % len(player_attack)

    def defnd_animation(self):
        self.image = pygame.image.load(player_defend[self.def_counter])
        self.def_counter = (self.def_counter + 1) % len(player_defend)

    def hit_animation(self):
        self.image = pygame.image.load(player_hit[self.hit_counter])
        self.hit_counter = (self.hit_counter + 1) % len(player_hit)
        
    def potion_animation(self):
        self.image = pygame.image.load(player_potion[self.potion_counter])
        self.potion_counter = (self.potion_counter + 1) % len(player_potion)

    def attack(self):
        hit_miss = random.randint(0, 20)
        damage = random.randint(0, self.atk)
        max_damage = self.atk
        if hit_miss >= 17:
            player_fight.atk_animation()
            status_text.text = ("Critical Hit!!!")
            pygame.time.delay(1000)
            status_text.text = ("You hit "+str(test_enemy.name)+" for "+str(max_damage * 2))
            swing_sound.play()
            test_enemy.hp = test_enemy.hp - max_damage*2
            pygame.time.delay(1000)
        elif hit_miss <= 3:
            status_text.text = ("You miss...")
            pygame.time.delay(1000)
        else:
            player_fight.atk_animation()
            if test_enemy.defnd_success == True:
                status_text.text = ("You hit "+str(test_enemy.name)+" for "+str((damage)-test_enemy.defnd))
                swing_sound.play()
                test_enemy.hp = test_enemy.hp - (damage - test_enemy.defnd)
                pygame.time.delay(1000)
            else:
                status_text.text = ("You hit "+str(test_enemy.name)+" for "+str(damage))
                swing_sound.play()
                test_enemy.hp = test_enemy.hp - damage
                pygame.time.delay(1000)

        player_hp_text.text = ("HP: "+str(player_fight.hp))
        enemy_hp_text.text = ("HP: "+str(test_enemy.hp))
        test_enemy.defnd_success = False

    def defend(self): #<-- If defend is successful enemy hits for less or negative damage
        hit_miss2 = random.randint(0, 20)
        if hit_miss2 >= 10:
            player_fight.defnd_animation()
            self.defnd_success = True
            status_text.text = ("You blocked.")
            defnd_sound.play()
            pygame.time.delay(1000)
            
        else:
            status_text.text = ("You failed to block...")
            pygame.time.delay(1000)

    def item(self):
        hit_miss = random.randint(0, 20)
        hp_gain = random.randint(0, 10)
        if self.potion_num == 0:
            status_text.text = ("You don't have any!")
            pygame.time.delay(1000)
        else:
            status_text.text = ("You drank a potion...")
            potion_sound.play()
            pygame.time.delay(1000)
            if hit_miss >= 2:
                status_text.text = ("You gained "+str(hp_gain)+" hp!!!")
                pygame.time.delay(1000)
                self.hp = self.hp + hp_gain
            else: #<-- Only has a small chance of failing
                status_text.text = ("It didn't work...")
                pygame.time.delay(1000)

    def run(self):
        hit_miss = random.randint(0, 20)
        if hit_miss >= 5:
            status_text.text = ("You got away safely...")
            pygame.time.delay(1000)
            Fight_screen_close()
        else:
            status_text.text = ("You couldn't escape!")
            pygame.time.delay(1000)

    def render(self, screen):
        screen.blit(self.image, (10, 100))
        

class Enemy:
    def __init__(self, x, y, width, height, image, atk_img, defnd_img, hit_img, buff_img, defeat_img, name, maxhp, hp, atk, defnd, buff_stat, defnd_success, reward):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        
        self.image = image
        self.atk_img = atk_img
        self.defnd_img = defnd_img
        self.hit_img = hit_img
        self.buff_img = buff_img

        self.name = name
        self.maxhp = maxhp
        self.hp = hp
        self.atk = atk
        self.defnd = defnd
        self.buff_stat = buff_stat #<-- Additional ability enemy can activate
        self.defnd_success = defnd_success #<-- If defend action is successful
        self.reward = reward #<--- How many points are gained from defeating the enemy

        #For animations
        self.atk_counter = 0
        self.def_counter = 0
        self.hit_counter = 0
        self.buff_counter = 0

        self.crit_chance = 17 #<-- attack roll needs to be greater to hit critically

    def dead(self):
        status_text.text = ("Enemy defeated!")
        pygame.time.delay(1000)
        self.hp = self.maxhp
        Fight_screen_close()

    def atk_animation(self):
        self.image = pygame.image.load(self.atk_img[self.atk_counter])
        self.atk_counter = (self.atk_counter + 1) % len(self.atk_img)

    def defnd_animation(self):
        self.image = pygame.image.load(self.defnd_img[self.def_counter])
        self.def_counter = (self.def_counter + 1) % len(self.defnd_img)

    def hit_animation(self):
        self.image = pygame.image.load(self.hit_img[self.hit_counter])
        self.hit_counter = (self.hit_counter + 1) % len(self.hit_img)

    def buff_animation(self):
        self.image = pygame.image.load(self.buff_img[self.buff_counter])
        self.buff_counter = (self.buff_counter + 1) % len(self.buff_img)

    def attack(self):
        global turn
        hit_miss = random.randint(0, 20)
        damage = random.randint(0, self.atk)
        max_damage = self.atk
        if hit_miss >= self.crit_chance:
            test_enemy.atk_animation()
            status_text.text = ("Critical Hit!!!")
            pygame.time.delay(1000)
            status_text.text = (str(test_enemy.name)+" hit for "+str(max_damage * 2))
            swing_sound.play()
            player_fight.hp = player_fight.hp - max_damage*2
            pygame.time.delay(1000)
        elif hit_miss <= 3:
            status_text.text = (str(test_enemy.name)+" missed!")
        else:
            test_enemy.atk_animation()
            if player_fight.defnd_success == True:
                status_text.text = (str(test_enemy.name)+" hit for "+str((damage)-player_fight.defnd))
                swing_sound.play()
                player_fight.hp = player_fight.hp - (damage - test_enemy.defnd)
                pygame.time.delay(1000)
            else:
                status_text.text = (str(test_enemy.name)+" hit for "+str(damage))
                swing_sound.play()
                player_fight.hp = player_fight.hp - damage
                pygame.time.delay(1000)
                
        player_hp_text.text = ("HP: "+str(player_fight.hp))
        enemy_hp_text.text = ("HP: "+str(test_enemy.hp))
        player_fight.defnd_success = False

    def defend(self): #<-- If defend is successful player hits for less or negative damage
        global turn
        turn = 0
        hit_miss2 = random.randint(0, 20)
        if hit_miss2 >= 10:
            test_enemy.defnd_animation()
            self.defnd_success = True
            status_text.text = (test_enemy.name+" blocked!")
            defnd_sound.play()
            pygame.time.delay(1000)
            
        else:
            status_text.text = (test_enemy.name+"'s block failed!")
            pygame.time.delay(1000)

    def buff(self): #<-- The enemy has a 'buff' ability rather than items
        global turn
        turn = 0

        if test_enemy.buff_stat == 0: #<-- Raise attack stat
            if test_enemy.atk >= 30:
                test_enemy.buff_animation()
                status_text.text = (test_enemy.name+''''s attack can't
go any higher!''')
                pygame.time.delay(1000)
            else:
                test_enemy.buff_animation()
                status_text.text = (test_enemy.name+"'s attack went up!")
                buff_sound.play()
                test_enemy.atk += 10
                pygame.time.delay(1000)

        if test_enemy.buff_stat == 1: #<-- Regain HP
            if test_enemy.hp >= 300:
                test_enemy.buff_animation()
                status_text.text = (test_enemy.name+" recovered 0 HP!")
                buff_sound.play()
                pygame.time.delay(1000)
            else:
                test_enemy.buff_animation()
                status_text.text = (test_enemy.name+" recovered 5 HP!")
                buff_sound.play()
                test_enemy.hp += 5
                pygame.time.delay(1000)

        if test_enemy.buff_stat == 2: #<-- Raise defense stat
            if test_enemy.defnd >= (player_fight.atk * 2):
                test_enemy.buff_animation()
                status_text.text = (test_enemy.name+''''s defense can't 
go any higher!''')
                pygame.time.delay(1000)
            else:
                test_enemy.buff_animation()
                status_text.text = (test_enemy.name+"'s defense went up!")
                buff_sound.play()
                test_enemy.defnd += 5
                pygame.time.delay(1000)

    def turn(self):
        global turn
        turn = 0
        decide = random.randint(1, 3)
        if decide == 1:
            status_text.text = (test_enemy.name+" attacked!")
            pygame.time.delay(1000)
            self.attack()
        if decide == 2:
            status_text.text = (test_enemy.name+" defended!")
            pygame.time.delay(1000)
            self.defend()
        if decide == 3:
            status_text.text = (test_enemy.name+" used it's buff!")
            pygame.time.delay(1000)
            self.buff()

    def render(self, screen):
        screen.blit(self.image, (self.x, 250))
        player_hp_text.text = ("HP: "+str(player_fight.hp))
        enemy_hp_text.text = ("HP: "+str(test_enemy.hp))
        
class Option:
    def __init__(self, text, pos, color):
        self.text = text
        self.pos = pos
        self.color = color
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

    def set_rend(self):
        self.rend = fontObj.render(self.text, True, self.color)

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos

class Status:
    def __init__(self, text, pos):
        self.text = text
        self.pos = pos
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

    def set_rend(self):
        self.rend = fontObj.render(self.text, True, BLACK)

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos

#Fight Screen Functions
global fighting

def Fight_screen_close():
    global fighting
    fighting = False

timer_event = pygame.USEREVENT + 1
pygame.time.set_timer(timer_event, 250)

def Fight_screen():
    global fighting
    global turn
    global pause
    global fight_text

    global pressed_left
    global pressed_right
    global pressed_up
    global pressed_down

    global mouse_down

    pressed_left = False
    pressed_right = False
    pressed_up = False
    pressed_down = False
    
    #Positioning:
    #Option1    Option3
    #Option2    Option4

    #Options text
    option1 = "ATTACK"
    option2 = "DEFEND"
    option3 = "POTION (x"+str(player_fight.potion_num)+")"
    option4 = "RUN"

    default_menu = True

    screen.fill(BLACK)
    screen.blit(fightbg, (0, 0))

    #Create options text
    opt1text = Option(option1, (50, 550), BLACK)
    opt2text = Option(option2, (50, 590), BLACK)
    opt3text = Option(option3, (200, 550), BLACK)
    opt4text = Option(option4, (200, 590), BLACK)

    #Blit HP text
    status_text.draw()
    player_hp_text.draw()
    enemy_hp_text.draw()
    
    #FIGHT SCREEN GAME LOOP
    while fighting:
        mouse_pos = pygame.mouse.get_pos() #<-- Get mouse location
        for event in pygame.event.get():
            #Change options text color when hovered over
            if opt1text.rect.collidepoint(mouse_pos):
                opt1text.color = WHITE
                opt1text.draw()
            else:
                opt1text.color = BLACK
                opt1text.draw()

            if opt2text.rect.collidepoint(mouse_pos):
                opt2text.color = WHITE
                opt2text.draw()
            else:
                opt2text.color = BLACK
                opt2text.draw()

            if opt3text.rect.collidepoint(mouse_pos):
                opt3text.color = WHITE
                opt3text.draw()
            else:
                opt3text.color = BLACK
                opt3text.draw()

            if opt4text.rect.collidepoint(mouse_pos):
                opt4text.color = WHITE
                opt4text.draw()
            else:
                opt4text.color = BLACK
                opt4text.draw()

            #Fight Screen Game Logic
            if event.type == pygame.NOEVENT:
                break
            else:
                if player_fight.hp <= 0:
                    player_fight.dead()
                if test_enemy.hp <= 0:
                    test_enemy.dead()
                    break
                    
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if turn == 0:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        #Click Option 1
                        if event.button == 1 and opt1text.rect.collidepoint(mouse_pos):
                            select_sound.play()
                            pygame.time.delay(500)
                            player_fight.attack()
                            turn = 1

                        #Click Option 2
                        if event.button == 1 and opt2text.rect.collidepoint(mouse_pos):
                            select_sound.play()
                            pygame.time.delay(500)
                            player_fight.defend()
                            turn = 1

                        #Click Option 3
                        if event.button == 1 and opt3text.rect.collidepoint(mouse_pos):
                            select_sound.play()
                            pygame.time.delay(500)
                            player_fight.item()
                            turn = 1

                        #Click Option 4
                        if event.button == 1 and opt4text.rect.collidepoint(mouse_pos):
                            mouse_down = True
                            select_sound.play()
                            pygame.time.delay(500)
                            player_fight.run()

                    screen.fill(BLACK)
                    screen.blit(fightbg, (0, 0))

                    #Blit options text
                    opt1text.draw()
                    opt2text.draw()
                    opt3text.draw()
                    opt4text.draw()
                    status_text.draw()
                    player_hp_text.draw()
                    enemy_hp_text.draw()
                    
                    player_fight.render(screen)
                    test_enemy.render(screen)
                else:
                    test_enemy.turn()

                key = pygame.key.get_pressed() #Get Keyboard Input
                if key[pygame.K_p]:
                    select_sound2.play()
                    pygame.time.delay(500)
                    pause = True
                    paused()
                
        pygame.display.flip()
    

#Pause Menu Functions
global pause
def unpaused():
    global pause
    pause = False

def paused():
    global pause
    #screen.fill(BLACK)
    textObj = fontObj.render('PAUSED', True, WHITE)
    textRect = textObj.get_rect()
    textRect.center = (345, 70)
    screen.blit(textObj, textRect)
    option1 = Option("RESUME", (270, 205), WHITE)
    option2 = Option("QUIT", (270, 255), WHITE)

    while pause: 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            mouse_pos = pygame.mouse.get_pos() #<-- Get mouse location

            if option1.rect.collidepoint(mouse_pos):
                option1.color = GRAY
                option1.draw()
            else:
                option1.color = WHITE
                option1.draw()

            if option2.rect.collidepoint(mouse_pos):
                option2.color = GRAY
                option2.draw()
            else:
                option2.color = WHITE
                option2.draw()

            #Click Resume
            if pygame.mouse.get_pressed()[0] and option1.rect.collidepoint(mouse_pos):
                select_sound2.play()
                pygame.time.delay(500)
                pause = False
                unpaused()

            #Click Quit
            if pygame.mouse.get_pressed()[0] and option2.rect.collidepoint(mouse_pos):
                select_sound2.play()
                pygame.time.delay(500)
                pygame.quit()
                sys.exit()
                
        pygame.display.flip()

#INITIALIZING CLASSES
#              (x, y, width, height)
player = Player(350, 350, 128, 128)

#            (x, y)
camera_pos = (192, 192)

#                          (x, y, width, height, hp, atk, defnd, potion_num, defnd_success)
player_fight = Player_Fight(100, 350, 128, 128, 100, 10, 10, 0, False)

#                  (x,   y, width, height, image,    atk_img,       defnd_img,    hit_img,    buff_img,    defeat_img,    name,      maxhp, hp, atk, defnd, buff_stat, defnd_success, reward)
enemy_list = [Enemy(450, 350, 128, 128, enemy1_idle, enemy1_attack, enemy1_defnd, enemy1_hit, enemy1_buff, enemy1_defeat, "Spider", 20, 20, 10, 10, 1, False, 10),
Enemy(450, 350, 128, 128, enemy2_idle, enemy2_attack, enemy2_defnd, enemy2_hit, enemy2_buff, enemy2_defeat, "Stump Monster", 70, 70, 10, 10, 0, False, 10),
Enemy(450, 350, 128, 128, enemy3_idle, enemy3_attack, enemy3_defnd, enemy3_hit, enemy3_buff, enemy3_defeat, "Rat", 50, 50, 10, 10, 2, False, 10),
Enemy(450, 350, 128, 128, enemy4_idle, enemy4_attack, enemy4_defnd, enemy4_hit, enemy4_buff, enemy4_defeat, "Tree", 70, 70, 10, 10, 0, False, 10),
Enemy(450, 350, 128, 128, enemy5_idle, enemy5_attack, enemy5_defnd, enemy5_hit, enemy5_buff, enemy5_defeat, "Junk Knight", 100, 100, 10, 10, 1, False, 10)]
test_enemy = random.choice(enemy_list)

#                   (text, pos)
status_text = Status(test_enemy.name+" appeared!", (250, 150))

#                      (text, pos)
player_hp_text = Status("HP: "+str(player_fight.hp), (player_fight.x, 450))

#                     (text, pos)
enemy_hp_text = Status("HP: "+str(test_enemy.hp), (test_enemy.x, 450))


#ENEMY ENCOUNTER TIMER
next_encounter = random.randint(100, 500) #<-- Change range to change encounter speed


#Create world
world.blit(bg, (0, 0))

#GAME LOOP
while True:
    clock.tick(60)    
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            
        elif event.type == pygame.KEYDOWN: #<-- if key is pressed        
            if event.key == pygame.K_LEFT:
                walk_sound.play()
                pressed_left = True
            elif event.key == pygame.K_RIGHT:
                walk_sound.play()
                pressed_right = True
            elif event.key == pygame.K_UP:
                walk_sound.play()
                pressed_up = True
            elif event.key == pygame.K_DOWN:
                walk_sound.play()
                pressed_down = True
            elif event.key == pygame.K_p: #<-- pause game
                pause = True
                select_sound2.play()
                pygame.time.delay(500)
                paused()

        elif event.type == pygame.KEYUP: #<-- if key is released
            if event.key == pygame.K_LEFT:
                walk_sound.stop()
                pressed_left = False
            elif event.key == pygame.K_RIGHT:
                walk_sound.stop()
                pressed_right = False
            elif event.key == pygame.K_UP:
                walk_sound.stop()
                pressed_up = False
            elif event.key == pygame.K_DOWN:
                walk_sound.stop()
                pressed_down = False

        test_enemy = random.choice(enemy_list)
        status_text.text = (test_enemy.name+" appeared!")

    #ENEMY ENCOUNTER
    if next_encounter > 0:
        next_encounter = next_encounter-1
    elif next_encounter == 0:
        fighting = True
        Fight_screen()
        next_encounter = random.randint(100, 500)
    else:
        next_encounter = random.randint(100, 500)


    #PLAYER SPRITE WALK CYCLE ANIMATION
    if pressed_right:
        player.image = pygame.image.load(player_right[right_counter])
        right_counter = (right_counter + 1) % len(player_right)
    if pressed_left:
        player.image = pygame.image.load(player_left[left_counter])
        left_counter = (left_counter + 1) % len(player_left)
    if pressed_down:
        player.image = pygame.image.load(player_down[down_counter])
        down_counter = (down_counter + 1) % len(player_down)
    if pressed_up:
        player.image = pygame.image.load(player_up[up_counter])
        up_counter = (up_counter + 1) % len(player_up)

        pygame.display.flip()
            
    camera_pos = player.move(camera_pos)
        
    screen.blit(bg, (0, 0))

    screen.blit(world, camera_pos)
    player.render(screen)
    
    pygame.display.flip()
