'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
'''

'''
Samantha Bennefield
1/9/18
Mr. Davis
Quest
Alpha Version 1
'''

import sys
import pygame
import random
import os
import subprocess

pygame.init()

WIDTH = 700
HEIGHT = 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Quest (Alpha 1)")

#COLORS
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (200, 200, 200)
RED   = (255, 0 , 0)
GREEN = (0, 255, 0)
BLUE  = (0, 0, 255)

#CLOCK
clock = pygame.time.Clock()

#FONT
fontObj = pygame.font.Font('freesansbold.ttf', 32)

#MUSIC
pygame.mixer.init()
pygame.mixer.music.load("08 Ascending.mp3")
pygame.mixer.music.set_volume(0.7)
pygame.mixer.music.play(-1, 0.0) #<--- Plays infinitely

effect = pygame.mixer.Sound("NFF-zing.wav")

#Open and close other python programs
def open_program(path_name):
    return subprocess.Popen(path_name)

def close_program(p):
    p.terminate()

class Option:
    def __init__(self, text, pos, color):
        self.text = text
        self.pos = pos
        self.color = color
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

    def set_rend(self):
        self.rend = fontObj.render(self.text, True, self.color)

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos

class Quest:
    def __init__(self, quest_num, reward, desc, completed):
        self.quest_num = quest_num
        self.reward = reward
        self.desc = desc
        self.completed = completed

    def render(self):
        textObj = fontObj.render("Quest "+str(self.quest_num), True, BLACK)
        textRect = textObj.get_rect()
        textRect.center = (360, 150)

        textObj2 = fontObj.render(str(self.desc), True, BLACK)
        textRect2 = textObj2.get_rect()
        textRect2.center = (360, 250)

        textObj3 = fontObj.render("Reward: "+str(self.reward), True, BLACK)
        textRect3 = textObj3.get_rect()
        textRect3.center = (360, 350)

        screen.blit(textObj, textRect)
        screen.blit(textObj2, textRect2)
        screen.blit(textObj3, textRect3)

def open_credits():
    p = open_program(['notepad.exe', 'Credits.txt'])

starttext = Option("Start", (318, 300), WHITE) #<-- The "Start" button on screen
credittext = Option("Credits", (298, 360), WHITE)

#Start Screen Loop
start_screen = False
while start_screen == False:
    screen.fill(BLACK)
    mouse_pos = pygame.mouse.get_pos()
    
    textObj = fontObj.render('Quest', True, WHITE)
    textRect = textObj.get_rect()
    textRect.center = (352, 100)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


        #If start text is hovered over or clicked
        if pygame.mouse.get_pressed()[0] and starttext.rect.collidepoint(mouse_pos):
            effect.play()
            pygame.time.delay(500)
            start_screen = True
            
        if starttext.rect.collidepoint(mouse_pos):
            starttext.color = GRAY
            starttext.draw()
        else:
            starttext.color = WHITE
            starttext.draw()


        #If credits text is hovered over or clicked
        if pygame.mouse.get_pressed()[0] and credittext.rect.collidepoint(mouse_pos):
            effect.play()
            open_credits()

        if credittext.rect.collidepoint(mouse_pos):
            credittext.color = GRAY
            credittext.draw()
        else:
            credittext.color = WHITE
            credittext.draw()

    screen.blit(textObj, textRect)
    starttext.draw()
    credittext.draw()
    pygame.display.flip()

#Instruction Screen Loop
instructions = False
while instructions == False:
    screen.fill(BLACK)
    textObj = fontObj.render('Instructions', True, WHITE)
    textRect = textObj.get_rect()
    textRect.center = (360, 100)

    textObj2 = fontObj.render('Use the arrow keys to move', True, WHITE)
    textRect2 = textObj2.get_rect()
    textRect2.center = (340, 300)

    textObj3 = fontObj.render('"P" opens the pause menu', True, WHITE)
    textRect3 = textObj2.get_rect()
    textRect3.center = (340, 330)

    textObj4 = fontObj.render('Click to select options', True, WHITE)
    textRect4 = textObj2.get_rect()
    textRect4.center = (340, 360)

    textObj5 = fontObj.render('To quit select quit from the pause menu', True, WHITE)
    textRect5 = textObj5.get_rect()
    textRect5.center = (340, 400)

    textObj6 = fontObj.render('Click to continue', True, WHITE)
    textRect6 = textObj6.get_rect()
    textRect6.center = (340, 500)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            
        elif pygame.mouse.get_pressed()[0]:
            effect.play()
            pygame.time.delay(500)
            instructions = True

    screen.blit(textObj, textRect)
    screen.blit(textObj2, textRect2)
    screen.blit(textObj3, textRect3)
    screen.blit(textObj4, textRect4)
    screen.blit(textObj5, textRect5)
    screen.blit(textObj6, textRect6)
    pygame.display.flip()

gotext = Option("Go", (280, 400), BLACK) #<-- The "Go" button on screen

#Used to make sure the program only registers one click
x1 = 0

current_quest = Quest(1, '10 pts', 'Fight monsters in the field', False)


#GAME LOOP
while True:
    clock.tick(60)
    mouse_pos = pygame.mouse.get_pos()

    if pygame.mouse.get_pressed()[0] and gotext.rect.collidepoint(mouse_pos):
        effect.play()
        pygame.time.delay(500)
        p = open_program(['python.exe', 'quest_lvl1_alpha.py'])
        pygame.quit()
        sys.exit()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if gotext.rect.collidepoint(mouse_pos):
            gotext.color = GRAY
            gotext.draw()
        else:
            gotext.color = BLACK
            gotext.draw()

    screen.fill(WHITE)
    current_quest.render()
    gotext.draw()
    pygame.display.flip()
            
